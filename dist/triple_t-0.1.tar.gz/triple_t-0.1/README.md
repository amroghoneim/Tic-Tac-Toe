# Project Description

This project implements Tic-Tac-Toe package in python using an object oriented design.