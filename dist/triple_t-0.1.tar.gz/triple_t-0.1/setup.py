from setuptools import setup

setup(name='triple_t',
      version='0.1',
      description='Tic Tac Toe game',
      packages=['triple_t'],
      author='Amro Ghoneim',
      author_email='amroghoneim@aucegypt.edu',
      zip_safe=False)
